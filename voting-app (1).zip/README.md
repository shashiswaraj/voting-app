# 🗳️ Voting App (HTML, CSS, Node.js, Express, EJS)

Create polls, vote, and see live results. Simple and beginner-friendly.

## Features
- Create a poll with 2+ options
- Shareable poll link
- Prevents duplicate voting per browser with a cookie
- Results page with percentage bars
- JSON file storage (no database needed)

## Tech
- Node.js + Express
- EJS templates for server-side HTML
- Vanilla HTML/CSS (dark, clean UI)

## Setup
```bash
cd voting-app
npm install
npm run start
# open http://localhost:3000
```

## Notes
- Votes are prevented per poll *per browser* using cookies (basic). For production, use user auth or IP/session/device checks.
- Data is saved to `data/polls.json` so it persists across restarts.
- To develop with auto-reload: `npm run dev` (requires nodemon, already in devDependencies).
