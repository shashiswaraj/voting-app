const express = require('express');
const path = require('path');
const fs = require('fs');
const cookieParser = require('cookie-parser');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

// --- Basic setup ---
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// --- Data store (JSON file for polls) ---
const DATA_FILE = path.join(__dirname, 'data', 'polls.json');

function loadPolls() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
  } catch (e) {
    return [];
  }
}

function savePolls(polls) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(polls, null, 2), 'utf-8');
}

// Ensure data file exists
if (!fs.existsSync(DATA_FILE)) savePolls([]);

// In-memory map of pollId -> Set of voter tokens (simple anti double-vote)
const voterTokens = new Map();

// --- Routes ---
app.get('/', (req, res) => {
  const polls = loadPolls();
  res.render('index', { polls });
});

// Create a new poll
app.post('/poll', (req, res) => {
  const { question, options } = req.body;
  const cleanedOptions = (Array.isArray(options) ? options : [options])
    .map(o => (o || '').trim())
    .filter(o => o.length > 0);

  if (!question || cleanedOptions.length < 2) {
    return res.status(400).send('Please provide a question and at least two options.');
  }

  const poll = {
    id: uuidv4(),
    question: question.trim(),
    options: cleanedOptions.map(text => ({ id: uuidv4(), text, votes: 0 })),
    createdAt: new Date().toISOString()
  };

  const polls = loadPolls();
  polls.unshift(poll);
  savePolls(polls);

  res.redirect(`/poll/${poll.id}`);
});

// Vote page
app.get('/poll/:id', (req, res) => {
  const polls = loadPolls();
  const poll = polls.find(p => p.id === req.params.id);
  if (!poll) return res.status(404).send('Poll not found');

  // Has the user already voted? (cookie-based)
  const votedCookie = req.cookies[`voted_${poll.id}`];
  const hasVoted = !!votedCookie;

  res.render('poll', { poll, hasVoted });
});

// Submit a vote
app.post('/poll/:id/vote', (req, res) => {
  const polls = loadPolls();
  const poll = polls.find(p => p.id === req.params.id);
  if (!poll) return res.status(404).send('Poll not found');

  // Check if already voted
  const votedCookie = req.cookies[`voted_${poll.id}`];
  if (votedCookie) {
    return res.redirect(`/results/${poll.id}`);
  }

  const { optionId } = req.body;
  const option = poll.options.find(o => o.id === optionId);
  if (!option) return res.status(400).send('Invalid option');

  option.votes += 1;
  savePolls(polls);

  // Set a cookie to prevent double voting
  const token = uuidv4();
  res.cookie(`voted_${poll.id}`, token, { httpOnly: true, maxAge: 1000 * 60 * 60 * 24 * 365 });

  // Track in-memory as well (not strictly necessary with cookie)
  if (!voterTokens.has(poll.id)) voterTokens.set(poll.id, new Set());
  voterTokens.get(poll.id).add(token);

  res.redirect(`/results/${poll.id}`);
});

// Results page
app.get('/results/:id', (req, res) => {
  const polls = loadPolls();
  const poll = polls.find(p => p.id === req.params.id);
  if (!poll) return res.status(404).send('Poll not found');

  const totalVotes = poll.options.reduce((sum, o) => sum + o.votes, 0);
  res.render('results', { poll, totalVotes });
});

// Simple API to get poll data as JSON (for client-side charts if needed)
app.get('/api/poll/:id', (req, res) => {
  const polls = loadPolls();
  const poll = polls.find(p => p.id === req.params.id);
  if (!poll) return res.status(404).json({ error: 'Poll not found' });
  const totalVotes = poll.options.reduce((sum, o) => sum + o.votes, 0);
  res.json({ poll, totalVotes });
});

app.listen(PORT, () => {
  console.log(`✅ Voting app running at http://localhost:${PORT}`);
});
